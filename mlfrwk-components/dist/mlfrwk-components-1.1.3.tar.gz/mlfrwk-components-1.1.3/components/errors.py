class NotConfigFile(Exception):
    pass

class MissingParameters(Exception):
    pass