# ML-Framework
Machine Learning framework used for general data science projects

### Version Control
**1.1.3**
In this release different exceptions were handled for the collector and container packages. As well, a new package errors.py was created containing custom exceptions contained in the previous mentioned point.

